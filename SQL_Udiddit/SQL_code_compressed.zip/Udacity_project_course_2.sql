-- Guideline 2.a - users table
CREATE TABLE users (
id SERIAL PRIMARY KEY,
username VARCHAR(25) NOT NULL,
login_last_time TIMESTAMP );

ALTER TABLE users 
ADD CONSTRAINT usernames_are_notempty CHECK(LENGTH(TRIM(username)) > 0 );

ALTER TABLE users 
ADD CONSTRAINT usernames_are_unique UNIQUE(username);


-- Guideline 2.b - topics table
CREATE TABLE topics (
id SERIAL PRIMARY KEY,
topic_name VARCHAR(30) NOT NULL,
topic_description VARCHAR(500)
);

ALTER TABLE topics 
ADD CONSTRAINT topicnames_are_notempty CHECK(LENGTH(TRIM(topic_name)) > 0 );

ALTER TABLE topics 
ADD CONSTRAINT topicnames_are_unique UNIQUE(topic_name);

-- Guideline 2.c - post table
CREATE TABLE post (
id SERIAL PRIMARY KEY,
post_title VARCHAR(100) NOT NULL,
time_created TIMESTAMP,
url VARCHAR,
text_content VARCHAR
);

ALTER TABLE post
ADD COLUMN id_user INTEGER REFERENCES users ON DELETE SET NULL,
ADD COLUMN id_topic INTEGER REFERENCES topics ON DELETE CASCADE,

ADD CONSTRAINT text_or_url CHECK (
(LENGTH(TRIM(text_content)) = 0) AND (LENGTH(TRIM(url)) > 0)  OR 
(LENGTH(TRIM(text_content)) > 0) AND (LENGTH(TRIM(url)) = 0)  ),

ADD CONSTRAINT post_title_not_empty CHECK( LENGTH( TRIM(post_title)) > 0);


-- Guideline 2.d - Comments table
-- (parent) comment -> id_prt_comm
CREATE TABLE comms (
id SERIAL PRIMARY KEY,
id_user INTEGER REFERENCES post ON DELETE SET NULL,
id_post INTEGER REFERENCES users ON DELETE CASCADE,
id_prt_comm INTEGER REFERENCES comms ON DELETE CASCADE,

text_content VARCHAR NOT NULL,
time_created TIMESTAMP,

CONSTRAINT text_content_is_notempty CHECK(LENGTH(TRIM(text_content)) > 0)
);

-- Guideline 2.e - Vote table
CREATE TABLE vote(
id SERIAL PRIMARY KEY,
id_user INTEGER REFERENCES users ON DELETE SET NULL,
id_post INTEGER,
vote INTEGER NOT NULL,

CONSTRAINT  a_user_one_vote UNIQUE (id_user, id_post),
CONSTRAINT  vote_down_up_value CHECK( vote = -1 OR vote = 1 )
);

-- Index creation
CREATE INDEX quick_find_user_byusername ON users(username);
CREATE INDEX quick_find_topic_by_topicname ON topics(topic_name);
CREATE INDEX quick_find_post_by_url ON post(url);





-- Part 3 Migrate the provided data

-- insert into users table
INSERT INTO users(username)
	SELECT DISTINCT username FROM bad_comments 
	UNION
	SELECT DISTINCT username FROM bad_posts 
	UNION
	SELECT DISTINCT regexp_split_to_table(downvotes, ',') FROM bad_posts
	UNION
	SELECT DISTINCT regexp_split_to_table(upvotes, ',') FROM bad_posts ;

-- insert into topics table
INSERT INTO topics(topic_name)
	SELECT DISTINCT topic FROM bad_posts ;

-- insert into post table
INSERT INTO post (post_title, url, text_content, id_topic, id_user)
	SELECT 
		LEFT(bp.title, 100),
		bp.url,
		bp.text_content,
		tp.id,
		us.id
	FROM bad_posts bp
	JOIN topics tp 
	ON bp.topic = tp.topic_name
	JOIN users us
	ON bp.username = us.username
;



--insert into votes table - downvotes
INSERT INTO vote (id_user, id_post, vote)

SELECT us.id,
tabl.id,
-1 AS vote_down

FROM (
	SELECT id, regexp_split_to_table(downvotes, ',') AS downv_usr
	FROM bad_posts
) tabl 
JOIN users us
ON tabl.downv_usr = us.username ;


--insert into votes table - upvotes
INSERT INTO vote (id_user, id_post, vote)

SELECT us.id,
tabl.id,
1 AS upvote

FROM (
	SELECT id, regexp_split_to_table(upvotes, ',') AS upv_usr
	FROM bad_posts  
) tabl 
JOIN users us
ON tabl.upv_usr = us.username ;



-- insert into comms table
INSERT INTO comms (id_user, id_post, text_content)
	SELECT
		us.id,
		pt.id,
		bd.text_content
	FROM users us
	JOIN bad_comments bd
	ON us.username = bd.username 
	JOIN post pt
	ON pt.id = bd.post_id ;


SELECT COUNT(*) FROM vote;